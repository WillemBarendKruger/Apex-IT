import { Apex_ITTemplatePage } from './app.po';

describe('Apex_IT App', function() {
  let page: Apex_ITTemplatePage;

  beforeEach(() => {
    page = new Apex_ITTemplatePage();
  });

  it('should display message saying app works', () => {
    page.navigateTo();
    expect(page.getParagraphText()).toEqual('app works!');
  });
});
